var app = angular.module('app', ['ui.router','ui.bootstrap']);

app.config(function($stateProvider, $urlRouterProvider) {
	//Main state
  var showsState = {
    name: 'shows',
    url: '/shows',
    templateUrl: 'components/shows/showsView.html',
    controller: 'ShowsController'
  }
  //Details state --> redirecting falls into todo
  var showState = {
    name: 'show',
    url: '/show/{id}',
    templateUrl: 'components/show/show.html',
    controller: 'ShowController',
    params: {showParam: null}
  }

  $stateProvider.state(showsState);
  $stateProvider.state(showState);

 $urlRouterProvider.otherwise("/shows");

});