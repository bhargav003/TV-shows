
app.controller('ShowController', ['$scope', '$http', '$state', '$stateParams', function($scope, $http, $state, $stateParams) {

// These should be refactored into the fn's and fn's and to add more features 
//Params to load the details page for time being getting data from the main state
$scope.showDetails = $stateParams.showParam;
//Review percentage , max and rate should be set. Ui-b stars should be added which are in to-do list
$scope.max = 10;

$scope.rate = $scope.showDetails.show.rating.average;

$scope.percent = 100 * ($scope.showDetails.show.rating.average / $scope.max);
//this is needed to add the comments which can be multiple so temporarily storing data into array 
$scope.comments =[];

//This adds the comments. setting it to true because need to trigger the comments

//that should be added and nullify the comments in the input after the add
$scope.addComments = function (comment){
	$scope.comments.push(comment);
	$scope.isComments = true;
	$scope.addedComments = null;
 }

}]);