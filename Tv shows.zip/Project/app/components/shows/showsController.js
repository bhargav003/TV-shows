
app.controller('ShowsController', ['$scope', '$http', '$state', function($scope, $http, $state) {


	//To-do 
		// create a service , factory and organize the code should add date picker and filter option in the main page
	//


	// To ge the data //
	//right now date is set to default and country which are parameters. these are in the to do list
	$http.get('http://api.tvmaze.com/schedule?country=US&date=2014-12-01')
	.then(function(response) {
		for(var i = 0; i<response.data.length; i++){
			response.data[i].show.summary = response.data[i].show.summary ?
			response.data[i].show.summary.replace(/(<([^>]+)>)/ig, "") : null; 
		}
		$scope.shows = response.data;
	});
	// this is the click event on the show which launches the details state//
	$scope.showDetail = function(show) {
		$state.go('show', {"showParam": show, "id": show.id});
	}

}]);